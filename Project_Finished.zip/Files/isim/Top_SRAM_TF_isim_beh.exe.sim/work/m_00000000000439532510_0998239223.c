/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/crist/OneDrive/CECS460/Project4/Files/Decode8to2.v";
static unsigned int ng1[] = {1U, 0U};
static unsigned int ng2[] = {0U, 0U};
static unsigned int ng3[] = {3U, 0U};
static unsigned int ng4[] = {2U, 0U};
static unsigned int ng5[] = {4U, 0U};
static unsigned int ng6[] = {5U, 0U};
static unsigned int ng7[] = {6U, 0U};
static unsigned int ng8[] = {7U, 0U};



static void Cont_19_0(char *t0)
{
    char t3[8];
    char t4[8];
    char t5[8];
    char t14[8];
    char *t1;
    char *t2;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t15;
    char *t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    char *t29;
    char *t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    char *t36;
    char *t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    char *t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    char *t46;
    char *t47;
    char *t48;
    char *t49;
    char *t50;
    char *t51;
    unsigned int t52;
    unsigned int t53;
    char *t54;
    unsigned int t55;
    unsigned int t56;
    char *t57;
    unsigned int t58;
    unsigned int t59;
    char *t60;

LAB0:    t1 = (t0 + 3328U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(19, ng0);
    t2 = (t0 + 1528U);
    t6 = *((char **)t2);
    memset(t5, 0, 8);
    t2 = (t6 + 4);
    t7 = *((unsigned int *)t6);
    t8 = *((unsigned int *)t6);
    t8 = (t8 & 1);
    if (*((unsigned int *)t2) != 0)
        goto LAB4;

LAB5:    t10 = 1;

LAB7:    t11 = (t10 <= 7);
    if (t11 == 1)
        goto LAB8;

LAB9:    *((unsigned int *)t5) = t8;

LAB6:    t13 = ((char*)((ng1)));
    memset(t14, 0, 8);
    t15 = (t5 + 4);
    t16 = (t13 + 4);
    t17 = *((unsigned int *)t5);
    t18 = *((unsigned int *)t13);
    t19 = (t17 ^ t18);
    t20 = *((unsigned int *)t15);
    t21 = *((unsigned int *)t16);
    t22 = (t20 ^ t21);
    t23 = (t19 | t22);
    t24 = *((unsigned int *)t15);
    t25 = *((unsigned int *)t16);
    t26 = (t24 | t25);
    t27 = (~(t26));
    t28 = (t23 & t27);
    if (t28 != 0)
        goto LAB14;

LAB11:    if (t26 != 0)
        goto LAB13;

LAB12:    *((unsigned int *)t14) = 1;

LAB14:    memset(t4, 0, 8);
    t30 = (t14 + 4);
    t31 = *((unsigned int *)t30);
    t32 = (~(t31));
    t33 = *((unsigned int *)t14);
    t34 = (t33 & t32);
    t35 = (t34 & 1U);
    if (t35 != 0)
        goto LAB15;

LAB16:    if (*((unsigned int *)t30) != 0)
        goto LAB17;

LAB18:    t37 = (t4 + 4);
    t38 = *((unsigned int *)t4);
    t39 = *((unsigned int *)t37);
    t40 = (t38 || t39);
    if (t40 > 0)
        goto LAB19;

LAB20:    t42 = *((unsigned int *)t4);
    t43 = (~(t42));
    t44 = *((unsigned int *)t37);
    t45 = (t43 || t44);
    if (t45 > 0)
        goto LAB21;

LAB22:    if (*((unsigned int *)t37) > 0)
        goto LAB23;

LAB24:    if (*((unsigned int *)t4) > 0)
        goto LAB25;

LAB26:    memcpy(t3, t46, 8);

LAB27:    t47 = (t0 + 4256);
    t48 = (t47 + 56U);
    t49 = *((char **)t48);
    t50 = (t49 + 56U);
    t51 = *((char **)t50);
    memset(t51, 0, 8);
    t52 = 1U;
    t53 = t52;
    t54 = (t3 + 4);
    t55 = *((unsigned int *)t3);
    t52 = (t52 & t55);
    t56 = *((unsigned int *)t54);
    t53 = (t53 & t56);
    t57 = (t51 + 4);
    t58 = *((unsigned int *)t51);
    *((unsigned int *)t51) = (t58 | t52);
    t59 = *((unsigned int *)t57);
    *((unsigned int *)t57) = (t59 | t53);
    xsi_driver_vfirst_trans(t47, 0, 0);
    t60 = (t0 + 4144);
    *((int *)t60) = 1;

LAB1:    return;
LAB4:    t9 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t9) = 1;
    goto LAB6;

LAB8:    t7 = (t7 >> 1);
    t12 = (t7 & 1);
    t8 = (t8 ^ t12);

LAB10:    t10 = (t10 + 1);
    goto LAB7;

LAB13:    t29 = (t14 + 4);
    *((unsigned int *)t14) = 1;
    *((unsigned int *)t29) = 1;
    goto LAB14;

LAB15:    *((unsigned int *)t4) = 1;
    goto LAB18;

LAB17:    t36 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t36) = 1;
    goto LAB18;

LAB19:    t41 = ((char*)((ng1)));
    goto LAB20;

LAB21:    t46 = ((char*)((ng2)));
    goto LAB22;

LAB23:    xsi_vlog_unsigned_bit_combine(t3, 1, t41, 1, t46, 1);
    goto LAB27;

LAB25:    memcpy(t3, t41, 8);
    goto LAB27;

}

static void Cont_20_1(char *t0)
{
    char t3[8];
    char t4[8];
    char t5[8];
    char t14[8];
    char *t1;
    char *t2;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t15;
    char *t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    char *t29;
    char *t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    char *t36;
    char *t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    char *t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    char *t46;
    char *t47;
    char *t48;
    char *t49;
    char *t50;
    char *t51;
    unsigned int t52;
    unsigned int t53;
    char *t54;
    unsigned int t55;
    unsigned int t56;
    char *t57;
    unsigned int t58;
    unsigned int t59;
    char *t60;

LAB0:    t1 = (t0 + 3576U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(20, ng0);
    t2 = (t0 + 1528U);
    t6 = *((char **)t2);
    memset(t5, 0, 8);
    t2 = (t6 + 4);
    t7 = *((unsigned int *)t6);
    t8 = *((unsigned int *)t6);
    t8 = (t8 & 1);
    if (*((unsigned int *)t2) != 0)
        goto LAB4;

LAB5:    t10 = 1;

LAB7:    t11 = (t10 <= 7);
    if (t11 == 1)
        goto LAB8;

LAB9:    *((unsigned int *)t5) = t8;

LAB6:    t13 = ((char*)((ng2)));
    memset(t14, 0, 8);
    t15 = (t5 + 4);
    t16 = (t13 + 4);
    t17 = *((unsigned int *)t5);
    t18 = *((unsigned int *)t13);
    t19 = (t17 ^ t18);
    t20 = *((unsigned int *)t15);
    t21 = *((unsigned int *)t16);
    t22 = (t20 ^ t21);
    t23 = (t19 | t22);
    t24 = *((unsigned int *)t15);
    t25 = *((unsigned int *)t16);
    t26 = (t24 | t25);
    t27 = (~(t26));
    t28 = (t23 & t27);
    if (t28 != 0)
        goto LAB14;

LAB11:    if (t26 != 0)
        goto LAB13;

LAB12:    *((unsigned int *)t14) = 1;

LAB14:    memset(t4, 0, 8);
    t30 = (t14 + 4);
    t31 = *((unsigned int *)t30);
    t32 = (~(t31));
    t33 = *((unsigned int *)t14);
    t34 = (t33 & t32);
    t35 = (t34 & 1U);
    if (t35 != 0)
        goto LAB15;

LAB16:    if (*((unsigned int *)t30) != 0)
        goto LAB17;

LAB18:    t37 = (t4 + 4);
    t38 = *((unsigned int *)t4);
    t39 = *((unsigned int *)t37);
    t40 = (t38 || t39);
    if (t40 > 0)
        goto LAB19;

LAB20:    t42 = *((unsigned int *)t4);
    t43 = (~(t42));
    t44 = *((unsigned int *)t37);
    t45 = (t43 || t44);
    if (t45 > 0)
        goto LAB21;

LAB22:    if (*((unsigned int *)t37) > 0)
        goto LAB23;

LAB24:    if (*((unsigned int *)t4) > 0)
        goto LAB25;

LAB26:    memcpy(t3, t46, 8);

LAB27:    t47 = (t0 + 4320);
    t48 = (t47 + 56U);
    t49 = *((char **)t48);
    t50 = (t49 + 56U);
    t51 = *((char **)t50);
    memset(t51, 0, 8);
    t52 = 1U;
    t53 = t52;
    t54 = (t3 + 4);
    t55 = *((unsigned int *)t3);
    t52 = (t52 & t55);
    t56 = *((unsigned int *)t54);
    t53 = (t53 & t56);
    t57 = (t51 + 4);
    t58 = *((unsigned int *)t51);
    *((unsigned int *)t51) = (t58 | t52);
    t59 = *((unsigned int *)t57);
    *((unsigned int *)t57) = (t59 | t53);
    xsi_driver_vfirst_trans(t47, 0, 0);
    t60 = (t0 + 4160);
    *((int *)t60) = 1;

LAB1:    return;
LAB4:    t9 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t9) = 1;
    goto LAB6;

LAB8:    t7 = (t7 >> 1);
    t12 = (t7 & 1);
    t8 = (t8 ^ t12);

LAB10:    t10 = (t10 + 1);
    goto LAB7;

LAB13:    t29 = (t14 + 4);
    *((unsigned int *)t14) = 1;
    *((unsigned int *)t29) = 1;
    goto LAB14;

LAB15:    *((unsigned int *)t4) = 1;
    goto LAB18;

LAB17:    t36 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t36) = 1;
    goto LAB18;

LAB19:    t41 = ((char*)((ng1)));
    goto LAB20;

LAB21:    t46 = ((char*)((ng2)));
    goto LAB22;

LAB23:    xsi_vlog_unsigned_bit_combine(t3, 1, t41, 1, t46, 1);
    goto LAB27;

LAB25:    memcpy(t3, t41, 8);
    goto LAB27;

}

static void Always_23_2(char *t0)
{
    char t4[8];
    char t13[8];
    char t14[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    int t9;
    char *t10;
    char *t11;
    char *t12;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;

LAB0:    t1 = (t0 + 3824U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(23, ng0);
    t2 = (t0 + 4176);
    *((int *)t2) = 1;
    t3 = (t0 + 3856);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(23, ng0);

LAB5:    xsi_set_current_line(24, ng0);
    t5 = (t0 + 1368U);
    t6 = *((char **)t5);
    t5 = (t0 + 1208U);
    t7 = *((char **)t5);
    t5 = (t0 + 1048U);
    t8 = *((char **)t5);
    xsi_vlogtype_concat(t4, 3, 3, 3U, t8, 1, t7, 1, t6, 1);

LAB6:    t5 = ((char*)((ng2)));
    t9 = xsi_vlog_unsigned_case_compare(t4, 3, t5, 3);
    if (t9 == 1)
        goto LAB7;

LAB8:    t2 = ((char*)((ng1)));
    t9 = xsi_vlog_unsigned_case_compare(t4, 3, t2, 3);
    if (t9 == 1)
        goto LAB9;

LAB10:    t2 = ((char*)((ng4)));
    t9 = xsi_vlog_unsigned_case_compare(t4, 3, t2, 3);
    if (t9 == 1)
        goto LAB11;

LAB12:    t2 = ((char*)((ng3)));
    t9 = xsi_vlog_unsigned_case_compare(t4, 3, t2, 3);
    if (t9 == 1)
        goto LAB13;

LAB14:    t2 = ((char*)((ng5)));
    t9 = xsi_vlog_unsigned_case_compare(t4, 3, t2, 3);
    if (t9 == 1)
        goto LAB15;

LAB16:    t2 = ((char*)((ng6)));
    t9 = xsi_vlog_unsigned_case_compare(t4, 3, t2, 3);
    if (t9 == 1)
        goto LAB17;

LAB18:    t2 = ((char*)((ng7)));
    t9 = xsi_vlog_unsigned_case_compare(t4, 3, t2, 3);
    if (t9 == 1)
        goto LAB19;

LAB20:    t2 = ((char*)((ng8)));
    t9 = xsi_vlog_unsigned_case_compare(t4, 3, t2, 3);
    if (t9 == 1)
        goto LAB21;

LAB22:
LAB24:
LAB23:    xsi_set_current_line(33, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 2248);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    t5 = (t0 + 2408);
    xsi_vlogvar_assign_value(t5, t2, 1, 0, 1);

LAB25:    goto LAB2;

LAB7:    xsi_set_current_line(25, ng0);
    t10 = ((char*)((ng3)));
    t11 = (t0 + 2248);
    xsi_vlogvar_assign_value(t11, t10, 0, 0, 1);
    t12 = (t0 + 2408);
    xsi_vlogvar_assign_value(t12, t10, 1, 0, 1);
    goto LAB25;

LAB9:    xsi_set_current_line(26, ng0);
    t3 = ((char*)((ng3)));
    t5 = (t0 + 2248);
    xsi_vlogvar_assign_value(t5, t3, 0, 0, 1);
    t6 = (t0 + 2408);
    xsi_vlogvar_assign_value(t6, t3, 1, 0, 1);
    goto LAB25;

LAB11:    xsi_set_current_line(27, ng0);
    t3 = (t0 + 1688U);
    t5 = *((char **)t3);
    t3 = ((char*)((ng1)));
    xsi_vlogtype_concat(t13, 2, 2, 2U, t3, 1, t5, 1);
    t6 = (t0 + 2248);
    xsi_vlogvar_assign_value(t6, t13, 0, 0, 1);
    t7 = (t0 + 2408);
    xsi_vlogvar_assign_value(t7, t13, 1, 0, 1);
    goto LAB25;

LAB13:    xsi_set_current_line(28, ng0);
    t3 = (t0 + 1848U);
    t5 = *((char **)t3);
    t3 = ((char*)((ng1)));
    xsi_vlogtype_concat(t13, 2, 2, 2U, t3, 1, t5, 1);
    t6 = (t0 + 2248);
    xsi_vlogvar_assign_value(t6, t13, 0, 0, 1);
    t7 = (t0 + 2408);
    xsi_vlogvar_assign_value(t7, t13, 1, 0, 1);
    goto LAB25;

LAB15:    xsi_set_current_line(29, ng0);
    t3 = (t0 + 1528U);
    t5 = *((char **)t3);
    memset(t14, 0, 8);
    t3 = (t14 + 4);
    t6 = (t5 + 4);
    t15 = *((unsigned int *)t5);
    t16 = (t15 >> 7);
    t17 = (t16 & 1);
    *((unsigned int *)t14) = t17;
    t18 = *((unsigned int *)t6);
    t19 = (t18 >> 7);
    t20 = (t19 & 1);
    *((unsigned int *)t3) = t20;
    t7 = ((char*)((ng1)));
    xsi_vlogtype_concat(t13, 2, 2, 2U, t7, 1, t14, 1);
    t8 = (t0 + 2248);
    xsi_vlogvar_assign_value(t8, t13, 0, 0, 1);
    t10 = (t0 + 2408);
    xsi_vlogvar_assign_value(t10, t13, 1, 0, 1);
    goto LAB25;

LAB17:    xsi_set_current_line(30, ng0);
    t3 = (t0 + 1528U);
    t5 = *((char **)t3);
    memset(t14, 0, 8);
    t3 = (t14 + 4);
    t6 = (t5 + 4);
    t15 = *((unsigned int *)t5);
    t16 = (t15 >> 7);
    t17 = (t16 & 1);
    *((unsigned int *)t14) = t17;
    t18 = *((unsigned int *)t6);
    t19 = (t18 >> 7);
    t20 = (t19 & 1);
    *((unsigned int *)t3) = t20;
    t7 = ((char*)((ng1)));
    xsi_vlogtype_concat(t13, 2, 2, 2U, t7, 1, t14, 1);
    t8 = (t0 + 2248);
    xsi_vlogvar_assign_value(t8, t13, 0, 0, 1);
    t10 = (t0 + 2408);
    xsi_vlogvar_assign_value(t10, t13, 1, 0, 1);
    goto LAB25;

LAB19:    xsi_set_current_line(31, ng0);
    t3 = (t0 + 1528U);
    t5 = *((char **)t3);
    memset(t14, 0, 8);
    t3 = (t14 + 4);
    t6 = (t5 + 4);
    t15 = *((unsigned int *)t5);
    t16 = (t15 >> 7);
    t17 = (t16 & 1);
    *((unsigned int *)t14) = t17;
    t18 = *((unsigned int *)t6);
    t19 = (t18 >> 7);
    t20 = (t19 & 1);
    *((unsigned int *)t3) = t20;
    t7 = (t0 + 1688U);
    t8 = *((char **)t7);
    xsi_vlogtype_concat(t13, 2, 2, 2U, t8, 1, t14, 1);
    t7 = (t0 + 2248);
    xsi_vlogvar_assign_value(t7, t13, 0, 0, 1);
    t10 = (t0 + 2408);
    xsi_vlogvar_assign_value(t10, t13, 1, 0, 1);
    goto LAB25;

LAB21:    xsi_set_current_line(32, ng0);
    t3 = (t0 + 1528U);
    t5 = *((char **)t3);
    memset(t14, 0, 8);
    t3 = (t14 + 4);
    t6 = (t5 + 4);
    t15 = *((unsigned int *)t5);
    t16 = (t15 >> 7);
    t17 = (t16 & 1);
    *((unsigned int *)t14) = t17;
    t18 = *((unsigned int *)t6);
    t19 = (t18 >> 7);
    t20 = (t19 & 1);
    *((unsigned int *)t3) = t20;
    t7 = (t0 + 1848U);
    t8 = *((char **)t7);
    xsi_vlogtype_concat(t13, 2, 2, 2U, t8, 1, t14, 1);
    t7 = (t0 + 2248);
    xsi_vlogvar_assign_value(t7, t13, 0, 0, 1);
    t10 = (t0 + 2408);
    xsi_vlogvar_assign_value(t10, t13, 1, 0, 1);
    goto LAB25;

}


extern void work_m_00000000000439532510_0998239223_init()
{
	static char *pe[] = {(void *)Cont_19_0,(void *)Cont_20_1,(void *)Always_23_2};
	xsi_register_didat("work_m_00000000000439532510_0998239223", "isim/Top_SRAM_TF_isim_beh.exe.sim/work/m_00000000000439532510_0998239223.didat");
	xsi_register_executes(pe);
}
